// Package wasmer is a Go library to run WebAssembly binaries.
package wasmer

// Empty module, so that we can install Wasmer through Cargo more easily.
